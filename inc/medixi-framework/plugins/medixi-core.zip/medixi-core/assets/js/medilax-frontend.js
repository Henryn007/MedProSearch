;(function($) {
    'use strict';
    $(window).on( 'elementor/frontend/init', function() {

        // Team Slider
        elementorFrontend.hooks.addAction('frontend/element_ready/medilaxdoctors.default',function($scope) {
            let $slickcarousels = $scope.find('.vs-carousel');
            $slickcarousels.not('.slick-initialized').slick({
                dots: false,
                infinite: true,
                arrows: $slickcarousels.data('slick-arrows'),
                prevArrow: '<button type="button" class="slick-prev"><i class="far fa-arrow-left"></i></button>',
                nextArrow: '<button type="button" class="slick-next"><i class="far fa-arrow-right"></i></button>',
                autoplay: $slickcarousels.data('slick-autoplay'),
                autoplaySpeed: 6000,
                fade: false,
                speed: 1000,
                slidesToShow: 3,
                slidesToScroll: 1,
                responsive: [{
                    breakpoint: 1500,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1
                    }
                }, {
                    breakpoint: 1350,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1
                    }
                }, {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        dots: false
                  }
                }, {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        dots: false
                  }
                }
              ]
            });
        });

        // Service Slider
        elementorFrontend.hooks.addAction('frontend/element_ready/medilaxservices.default',function($scope) {
            let $slickcarousels = $scope.find('.vs-carousel');
            $slickcarousels.not('.slick-initialized').slick({
                dots: false,
                infinite: true,
                arrows: false,
                prevArrow: '<button type="button" class="slick-prev"><i class="far fa-arrow-left"></i></button>',
                nextArrow: '<button type="button" class="slick-next"><i class="far fa-arrow-right"></i></button>',
                autoplay: $slickcarousels.data('slick-autoplay'),
                autoplaySpeed: 6000,
                fade: false,
                speed: 1000,
                slidesToShow: 3,
                slidesToScroll: 1,
                responsive: [{
                    breakpoint: 1500,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1
                    }
                }, {
                    breakpoint: 1350,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1
                    }
                }, {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        dots: false
                  }
                }, {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        dots: false
                  }
                }
              ]
            });

            let $slickcarousels2 = $scope.find('.vs-carousel2');
            $slickcarousels2.not('.slick-initialized').slick({
                dots: false,
                infinite: true,
                arrows: false,
                prevArrow: '<button type="button" class="slick-prev"><i class="far fa-arrow-left"></i></button>',
                nextArrow: '<button type="button" class="slick-next"><i class="far fa-arrow-right"></i></button>',
                autoplay: $slickcarousels2.data('slick-autoplay'),
                autoplaySpeed: 6000,
                fade: false,
                speed: 1000,
                slidesToShow: 3,
                slidesToScroll: 1,
                responsive: [{
                    breakpoint: 1500,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1
                    }
                }, {
                    breakpoint: 1350,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1
                    }
                }, {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        dots: false
                  }
                }, {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        dots: false
                  }
                }
              ]
            });
        });

        // Testimonials
        elementorFrontend.hooks.addAction('frontend/element_ready/medilaxtestimonials.default',function($scope) {
            
            let $slickcarousels = $scope.find('.vs-carousel');
            $slickcarousels.not('.slick-initialized').slick({
                dots: false,
                infinite: true,
                arrows: $slickcarousels.data('arrows'),
                autoplay: true,
                arrows: false,
                autoplaySpeed: 6000,
                fade: $slickcarousels.data('fade'),
                speed: 1000,
                slidesToShow: $slickcarousels.data('data-slide-show'),
                asNavFor: ($slickcarousels.data('asnavfor') ? $slickcarousels.data('asnavfor') : false),
                slidesToScroll: 1,
                slidesToShow: 2,
                focusOnSelect: true,
                responsive: [{
                    breakpoint: 1500,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1
                    }
                }, {
                    breakpoint: 1350,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1
                    }
                }, {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        dots: false
                  }
                }, {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        dots: false
                  }
                }
              ]
            });

            let $testislider = $scope.find('.vs-testislider');
            $testislider.not('.slick-initialized').slick({
                dots: false,
                infinite: true,
                autoplay: true,
                arrows: false,
                autoplaySpeed: 6000,
                speed: 1000,
                slidesToScroll: 1,
                slidesToShow: 3,
                focusOnSelect: true,
                responsive: [{
                    breakpoint: 1500,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1
                    }
                }, {
                    breakpoint: 1350,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1
                    }
                }, {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                        dots: false
                  }
                }, {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        dots: false
                  }
                }
              ]
            });

        });

        // Client Logo
        elementorFrontend.hooks.addAction('frontend/element_ready/medilaxclientlogo.default',function($scope) {
            let $logoslider = $scope.find('.vs-carousel');
            $logoslider.not('.slick-initialized').slick({
                infinite: true,
                arrows: false,
                autoplay: true,
                autoplaySpeed: 5000,
                speed: 1000,
                fade: false,
                slidesToShow: $logoslider.data('data-slide-show'),
                slidesToScroll: 1,
                slidesToShow: 5,
                centerMode: $logoslider.data('centermode'),
                centerPadding: $logoslider.data('centerpadding'),
                responsive: [{
                    breakpoint: 1500,
                    settings: {
                        slidesToShow: 5,
                        slidesToScroll: 1
                    }
                }, {
                    breakpoint: 1350,
                    settings: {
                        slidesToShow: 5,
                        slidesToScroll: 1
                    }
                }, {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1
                  }
                }, {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                  }
                }
              ]
            });
        });

        // Project
        elementorFrontend.hooks.addAction('frontend/element_ready/medilaxproject.default',function($scope) {
            let $project_slide = $scope.find('.vs-carousel');
            $project_slide.not('.slick-initialized').slick({
                infinite: true,
                arrows: false,
                autoplay: true,
                autoplaySpeed: 5000,
                speed: 1000,
                fade: false,
                slidesToShow: $project_slide.data('data-slide-show'),
                slidesToScroll: 1,
                slidesToShow: 3,
                centerMode: $project_slide.data('centermode'),
                centerPadding: $project_slide.data('centerpadding'),
                responsive: [{
                    breakpoint: 1500,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1
                    }
                }, {
                    breakpoint: 1350,
                    settings: {
                        slidesToShow: 3,
                        slidesToScroll: 1
                    }
                }, {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1
                  }
                }, {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                  }
                }
              ]
            });
        });

        // blog post type
        elementorFrontend.hooks.addAction('frontend/element_ready/medilaxblog.default',function($scope) {
            let $blog_post = $scope.find('.vs-carousel');
            // Blog Layout 1 Slider
             $blog_post.not('.slick-initialized').slick({
                dots: false,
                infinite: true,
                arrows: false,
                autoplay: true,
                autoplaySpeed: 8000,
                fade: false,
                speed: 1300,
                slidesToShow: $blog_post.data('data-slide-show'),
                slidesToScroll: 1,
                slidesToShow: 3,
                responsive: [{
                    breakpoint: 1500,
                    settings: {
                        slidesToShow: 3
                    }
                }, {
                    breakpoint: 1200,
                    settings: {
                        slidesToShow: 2
                    }
                },  {
                    breakpoint: 992,
                    settings: {
                        slidesToShow: 2
                    }
                },  {
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 1
                    }
                }
              ]
            });

        });

        // Client Logo
        elementorFrontend.hooks.addAction('frontend/element_ready/medilaxofferdate.default',function($scope) {
            let $countdown = $scope.find('.offer-counter');
            $.fn.countdown = function () {
                $(this).each(function () {
                  var $counter = $(this),
                    countDownDate = new Date($counter.data('offer-date')).getTime(), // Set the date we're counting down toz
                    exprireCls = 'expired';

                  // Finding Function
                  function s$(element) {
                    return $counter.find(element);
                  }

                  // Update the count down every 1 second
                  var counter = setInterval(function () {
                    // Get today's date and time
                    var now = new Date().getTime();

                    // Find the distance between now and the count down date
                    var distance = countDownDate - now;

                    // Time calculations for days, hours, minutes and seconds
                    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
                    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                    var seconds = Math.floor((distance % (1000 * 60)) / 1000);

                    // If the count down is over, write some text
                    if (distance < 0) {
                      clearInterval(counter);
                      $counter.addClass(exprireCls);
                      $counter.find('.message').css('display', 'block');
                    } else {
                      // Output the result in elements
                      s$('.day').html(days + ' ')
                      s$('.hour').html(hours + ' ')
                      s$('.minute').html(minutes + ' ')
                      s$('.seconds').html(seconds + ' ')
                    }
                  }, 1000);
                })
            }
        $countdown.countdown();

        });



        
    });
}(jQuery));

