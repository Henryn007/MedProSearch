<?php

// Comment is needed for certain versions of PHP to avoid parse error.